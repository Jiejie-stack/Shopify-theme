document.addEventListener("DOMContentLoaded", () => {
    const isLowPerformanceDevice = navigator.hardwareConcurrency <= 4;

    const lenis = new Lenis({
        duration: isLowPerformanceDevice ? 0.8 : 1.2,
        easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
        smooth: !window.matchMedia('(prefers-reduced-motion: reduce)').matches,
        smoothTouch: false,
    });

    function raf(time) {
        lenis.raf(time);
        requestAnimationFrame(raf);
    }

    requestAnimationFrame(raf);

    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const targetId = this.getAttribute('href');
            if (targetId !== '#') {
                e.preventDefault();
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    lenis.scrollTo(targetElement, { offset: -50, duration: 1.5 });
                }
            }
        });
    });

    gsap.registerPlugin(ScrollTrigger);

    const heroTl = gsap.timeline();

    heroTl.from(".hero-placeholder", {
        scale: 1.2,
        duration: 1.5,
        ease: "power2.out",
        transformOrigin: "center center",
        force3D: true
    })
        .from(".eyebrow", {
            y: 20,
            opacity: 0,
            duration: 0.8,
            ease: "power2.out"
        }, "-=1")
        .from(".hero-title", {
            y: 50,
            opacity: 0,
            duration: 1,
            ease: "power3.out"
        }, "-=0.8")
        .from(".hero-desc", {
            y: 30,
            opacity: 0,
            duration: 0.8,
            ease: "power2.out"
        }, "-=0.8")
        .from(".hero-buttons", {
            y: 20,
            opacity: 0,
            duration: 0.8,
            ease: "power2.out"
        }, "-=0.6");

    gsap.from(".quote-container", {
        scrollTrigger: {
            trigger: ".quote-section",
            start: "top 80%",
            end: "bottom 60%",
            toggleActions: "play none none reverse"
        },
        y: 50,
        opacity: 0,
        duration: 1.5,
        ease: "power3.out"
    });

    const impactTl = gsap.timeline({
        scrollTrigger: {
            trigger: ".impact-section",
            start: "center center",
            end: "+=200%", 
            pin: true,
            scrub: 1,
            anticipatePin: 1
        }
    });

    const items = gsap.utils.toArray(".bento-item");

    items.forEach((item, i) => {
        impactTl.to(item, {
            clipPath: "inset(0 0% 0 0)",
            duration: 1,
            ease: "power2.inOut"
        }, i * 0.8);
    });



    gsap.from(".cta-content", {
        scrollTrigger: {
            trigger: ".cta-section",
            start: "top 70%",
        },
        scale: 0.9,
        opacity: 0,
        duration: 1,
        ease: "back.out(1.7)"
    });

});
