let currentModalHandle = null;

document.addEventListener('DOMContentLoaded', () => {

    // SECTION 1: INITIALIZATION AND DATA FETCHING
    const state = { selectedComponents: {} };
    const modal = document.getElementById('component-modal');
    const modalContent = modal.querySelector('.modal-content');
    const modalTitle = document.getElementById('modal-title');
    const modalBody = document.getElementById('modal-body');
    const closeBtn = document.querySelector('.close-btn');
    const addToCartBtn = document.getElementById('add-to-cart-btn');
    const builderStepsEl = document.getElementById('builder-steps');
    const summaryItemsEl = document.getElementById('summary-items');
    const totalPriceEl = document.getElementById('total-price');
    const messageEl = document.getElementById('builder-message');

    async function initializeApp() {
        builderStepsEl.innerHTML = `<div class="loading-spinner-container"><div class="loading-spinner"></div></div>`;
        const { storefrontApiToken, storeUrl, components } = window.pcBuilderConfig;
        const storefrontEndpoint = `${storeUrl}/api/2024-07/graphql.json`;
        window.pcBuilderData = {};
        window.componentHandles = [];
        async function fetchProductsByTag(tag) {
            const query = `
                query getProductsByTag($tag: String!) {
                  products(first: 250, query: $tag) {
                    edges {
                      node {
                        id
                        title
                        handle
                        tags
                        availability: metafield(namespace: "custom", key: "availability_option") { value }
                        featuredImage { url(transform: {maxWidth: 200, maxHeight: 200}) }
                        variants(first: 1) { edges { node { id, price { amount, currencyCode } } } }
                      }
                    }
                  }
                }`;
            try {
                const response = await fetch(storefrontEndpoint, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Shopify-Storefront-Access-Token': storefrontApiToken },
                    body: JSON.stringify({ query, variables: { tag: `tag:${tag}` } }),
                });
                const jsonResponse = await response.json();
                if (jsonResponse.errors) {
                    console.error("GraphQL Errors:", jsonResponse.errors);
                    throw new Error(JSON.stringify(jsonResponse.errors));
                }
                return jsonResponse.data.products.edges
                    .filter(edge => {
                        const availabilityMetafield = edge.node.availability;
                        const valueToBlock = "❌ Back Order - Contact Us for ETA";
                        if (!availabilityMetafield) return true;
                        return availabilityMetafield.value !== valueToBlock;
                    })
                    .map(edge => {
                        const product = edge.node;
                        const variant = product.variants.edges[0].node;
                        const variantGid = variant.id;
                        const legacyVariantId = parseInt(variantGid.split('/').pop(), 10);
                        return {
                            id: product.id, variantId: variantGid, legacyVariantId: legacyVariantId,
                            title: product.title, tags: product.tags,
                            price: Math.round(parseFloat(variant.price.amount) * 100),
                            priceFormatted: `\$${parseFloat(variant.price.amount).toFixed(2)}`,
                            image: product.featuredImage ? product.featuredImage.url : 'https://cdn.shopify.com/s/files/1/0575/2733/3479/files/placeholder-image.png',
                        };
                    });
            } catch (error) {
                console.error(`Failed to fetch products for tag "${tag}":`, error);
                messageEl.textContent = `Error loading components.`;
                messageEl.className = 'text-center mt-4 text-sm text-red-600';
                return [];
            }
        }
        for (const component of components) {
            const componentKey = component.requiredTag.replace(/[^a-z0-9]/gi, '').toLowerCase();
            window.componentHandles.push(componentKey);
            const products = await fetchProductsByTag(component.requiredTag);
            window.pcBuilderData[componentKey] = { name: component.displayName, products: products };
        }
        renderComponentRows();
        updateUI();
    }


    // SECTION 2: UI RENDERING & LOGIC
    function renderComponentRows() {
        builderStepsEl.innerHTML = '';
        window.componentHandles.forEach(handle => {
            const componentData = window.pcBuilderData[handle];
            if (!componentData) return;
            const row = document.createElement('div');
            row.className = "component-row bg-transparent rounded-xl p-5 flex items-center justify-between transition-all duration-300 border-l-4 border-transparent";
            row.id = `row-${handle}`;

            let titleHtml = `<h2 class="component-title text-lg font-semibold text-[color:var(--pcb-text-light)]">${componentData.name}</h2>`;
            if (handle === 'cpu') {
                titleHtml = `
                <div class="flex items-center gap-3">
                    <img src="https://img.icons8.com/wired/64/processor.png" 
                         width="36" height="36" 
                         alt="CPU" 
                         class="flex-shrink-0 rounded-lg shadow-sm hover:scale-110 transition-transform duration-200"
                         title="CPU" />
                    <h2 class="component-title text-lg font-semibold text-[color:var(--pcb-text-light)]">${componentData.name}</h2>
                </div>`;
            }
            if (handle === 'case') {
                titleHtml = `
                <div class="flex items-center gap-3">
                    <img src="https://img.icons8.com/external-rabit-jes-detailed-outline-rabit-jes/62/external-computer-case-computer-hardware-rabit-jes-detailed-outline-rabit-jes.png" 
                         width="36" height="36" 
                         alt="Case" 
                         class="flex-shrink-0 rounded-lg shadow-sm hover:scale-110 transition-transform duration-200"
                         title="Case" />
                    <h2 class="component-title text-lg font-semibold text-[color:var(--pcb-text-light)]">${componentData.name}</h2>
                </div>`;
            }
            if (handle === 'cooler') {
                titleHtml = `
                <div class="flex items-center gap-3">
                    <img src="https://img.icons8.com/external-pixer-icons-pack-dmitry-mirolyubov/44/external-computer-computer-pixer-icons-pack-dmitry-mirolyubov-9.png" 
                         width="36" height="36" 
                         alt="cooler" 
                         class="flex-shrink-0 rounded-lg shadow-sm hover:scale-110 transition-transform duration-200"
                         title="cooler" />
                    <h2 class="component-title text-lg font-semibold text-[color:var(--pcb-text-light)]">${componentData.name}</h2>
                </div>`;
            }
            if (handle === 'motherboard') {
                titleHtml = `
                <div class="flex items-center gap-3">
                    <img src="https://img.icons8.com/ios/50/motherboard.png" 
                         width="36" height="36" 
                         alt="motherboard" 
                         class="flex-shrink-0 rounded-lg shadow-sm hover:scale-110 transition-transform duration-200"
                         title="motherboard" />
                    <h2 class="component-title text-lg font-semibold text-[color:var(--pcb-text-light)]">${componentData.name}</h2>
                </div>`;
            }
            if (handle === 'ram') {
                titleHtml = `
                <div class="flex items-center gap-3">
                    <img src="https://img.icons8.com/external-rabit-jes-detailed-outline-rabit-jes/62/external-ram-computer-hardware-rabit-jes-detailed-outline-rabit-jes-2.png" 
                         width="36" height="36" 
                         alt="ram" 
                         class="flex-shrink-0 rounded-lg shadow-sm hover:scale-110 transition-transform duration-200"
                         title="ram" />
                    <h2 class="component-title text-lg font-semibold text-[color:var(--pcb-text-light)]">${componentData.name}</h2>
                </div>`;
            }
            if (handle === 'storagessd') {
                titleHtml = `
                <div class="flex items-center gap-3">
                    <img src="https://img.icons8.com/ios/50/ssd.png" 
                         width="36" height="36" 
                         alt="ssd" 
                         class="flex-shrink-0 rounded-lg shadow-sm hover:scale-110 transition-transform duration-200"
                         title="storagessd" />
                    <h2 class="component-title text-lg font-semibold text-[color:var(--pcb-text-light)]">${componentData.name}</h2>
                </div>`;
            }
            if (handle === 'storagehdd') {
                titleHtml = `
                <div class="flex items-center gap-3">
                    <img src="https://img.icons8.com/ios/50/hdd.png" 
                         width="36" height="36" 
                         alt="storagehdd" 
                         class="flex-shrink-0 rounded-lg shadow-sm hover:scale-110 transition-transform duration-200"
                         title="storagehdd" />
                    <h2 class="component-title text-lg font-semibold text-[color:var(--pcb-text-light)]">${componentData.name}</h2>
                </div>`;
            }
            if (handle === 'networkcard') {
                titleHtml = `
                <div class="flex items-center gap-3">
                    <img src="https://img.icons8.com/ios/50/network-card.png" 
                         width="36" height="36" 
                         alt="networkcard" 
                         class="flex-shrink-0 rounded-lg shadow-sm hover:scale-110 transition-transform duration-200"
                         title="networkcard" />
                    <h2 class="component-title text-lg font-semibold text-[color:var(--pcb-text-light)]">${componentData.name}</h2>
                </div>`;
            }
            if (handle === 'graphiccard') {
                titleHtml = `
                <div class="flex items-center gap-3">
                    <img src="https://img.icons8.com/ios/50/video-card.png" 
                         width="36" height="36" 
                         alt="graphic card" 
                         class="flex-shrink-0 rounded-lg shadow-sm hover:scale-110 transition-transform duration-200"
                         title="graphic card" />
                    <h2 class="component-title text-lg font-semibold text-[color:var(--pcb-text-light)]">${componentData.name}</h2>
                </div>`;
            }
            if (handle === 'desktoppowersupply') {
                titleHtml = `
                <div class="flex items-center gap-3">
                    <img src="https://img.icons8.com/external-rabit-jes-detailed-outline-rabit-jes/62/external-power-supply-computer-hardware-rabit-jes-detailed-outline-rabit-jes.png" 
                         width="36" height="36" 
                         alt="power supply" 
                         class="flex-shrink-0 rounded-lg shadow-sm hover:scale-110 transition-transform duration-200"
                         title="power supply" />
                    <h2 class="component-title text-lg font-semibold text-[color:var(--pcb-text-light)]">${componentData.name}</h2>
                </div>`;
            }
            if (handle === 'monitor') {
                titleHtml = `
                <div class="flex items-center gap-3">
                    <img src="https://img.icons8.com/ios/50/monitor--v1.png" 
                         width="36" height="36" 
                         alt="monitor" 
                         class="flex-shrink-0 rounded-lg shadow-sm hover:scale-110 transition-transform duration-200"
                         title="monitor" />
                    <h2 class="component-title text-lg font-semibold text-[color:var(--pcb-text-light)]">${componentData.name}</h2>
                </div>`;
            }
            if (handle === 'operatingsystem') {
                titleHtml = `
                <div class="flex items-center gap-3">
                    <img src="https://img.icons8.com/ios/50/operating-system.png" 
                         width="36" height="36" 
                         alt="operating system" 
                         class="flex-shrink-0 rounded-lg shadow-sm hover:scale-110 transition-transform duration-200"
                         title="operating system" />
                    <h2 class="component-title text-lg font-semibold text-[color:var(--pcb-text-light)]">${componentData.name}</h2>
                </div>`;
            }
            row.innerHTML = `
            <div class="component-info flex-grow">
                ${titleHtml}
                <div class="selected-component mt-2" id="selected-${handle}">
                    <p class="placeholder text-[color:var(--pcb-text-muted)] text-sm">Click 'Choose' to select an item</p>
                </div>
            </div>
            <div class="component-action ml-4">
                <button class="select-btn w-28 bg-transparent border border-[color:var(--pcb-text-light)] text-[color:var(--pcb-text-light)] font-semibold py-2 px-4 rounded-lg hover:bg-[color:var(--pcb-text-light)] hover:text-black focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-white" data-handle="${handle}">Choose</button>
            </div>`;

            builderStepsEl.appendChild(row);
        });
    }

    function renderModalProducts(products, handle) {
        const productListContainer = document.getElementById('modal-product-list');
        if (!productListContainer) return;
        products.sort((a, b) => a.title.localeCompare(b.title));
        productListContainer.innerHTML = '';
        if (products.length === 0) {
            productListContainer.innerHTML = `<p class="text-[color:var(--pcb-text-muted)] text-center p-8">No products found matching the search or filter.</p>`;
        } else {
            products.forEach(product => {
                const productDiv = document.createElement('div');
                productDiv.className = 'product-item flex items-center gap-4 p-4 rounded-lg cursor-pointer hover:bg-[color:var(--pcb-accent-hover)] transition-colors';
                productDiv.addEventListener('click', () => selectProduct(handle, product));
                productDiv.innerHTML = `<img src="${product.image}" alt="${product.title}" class="w-20 h-20 object-cover rounded-md flex-shrink-0"><div class="info flex-grow"><p class="title font-semibold text-[color:var(--pcb-text-light)]">${product.title}</p></div><p class="price text-lg font-medium text-[color:var(--pcb-primary-color)]">${product.priceFormatted}</p>`;
                productListContainer.appendChild(productDiv);
            });
        }
    }

    function filterAndRenderProducts(handle, productsToShow) {
        const activeFilterBtn = document.querySelector('.modal-filter-btn.active');
        const activeFilter = activeFilterBtn ? activeFilterBtn.dataset.filter : 'All';

        const searchInput = document.getElementById('modal-search-input');
        const searchQuery = searchInput ? searchInput.value.trim().toLowerCase() : '';

        let filteredProducts = productsToShow;

        if (activeFilter !== 'All') {
            filteredProducts = filteredProducts.filter(p =>
                p.tags.some(tag => tag.toLowerCase() === activeFilter.toLowerCase())
            );
        }

        if (searchQuery) {
            filteredProducts = filteredProducts.filter(p =>
                p.title.toLowerCase().includes(searchQuery)
            );
        }

        filteredProducts.sort((a, b) => a.title.localeCompare(b.title));
        renderModalProducts(filteredProducts, handle);
    }

    function openModal(handle) {
        currentModalHandle = handle;
        const componentData = window.pcBuilderData[handle];
        const componentConfig = window.pcBuilderConfig.components.find(c => c.requiredTag.replace(/[^a-z0-9]/gi, '').toLowerCase() === handle);
        if (!componentData) return;

        let productsToShow = componentData.products;

        let compatibilityFilterApplied = false;

        if (handle === 'motherboard') {
            const cpuSelection = state.selectedComponents['cpu'] ? state.selectedComponents['cpu'][0] : null;
            if (cpuSelection) {
                const cpuTags = new Set(cpuSelection.product.tags.map(t => t.toLowerCase()));
                let requiredMoboTags = []; 
                
                if (cpuTags.has('intel-12gen') || cpuTags.has('intel-13gen') || cpuTags.has('intel-14gen')) {
                    requiredMoboTags = ['lga1700'];
                } else if (cpuTags.has('intel-ultra')) {
                    requiredMoboTags = ['lga1851']; 
                } else if (cpuTags.has('amd')) {
                    requiredMoboTags = ['amd-am5', 'wrx90']; 
                }

                if (requiredMoboTags.length > 0) { 
                    productsToShow = productsToShow.filter(mobo =>
                        mobo.tags.some(t => requiredMoboTags.includes(t.toLowerCase()))
                    );
                    compatibilityFilterApplied = true;
                }
            }
        } else if (handle === 'cpu') {
            const moboSelection = state.selectedComponents['motherboard'] ? state.selectedComponents['motherboard'][0] : null;
            if (moboSelection) {
                const moboTags = new Set(moboSelection.product.tags.map(t => t.toLowerCase()));
                let requiredCpuTags = [];
                if (moboTags.has('lga1700')) {
                    requiredCpuTags = ['intel-12gen', 'intel-13gen', 'intel-14gen'];
                } else if (moboTags.has('lga1851')) {
                    requiredCpuTags = ['intel-ultra'];
                } else if (moboTags.has('amd-am5') || moboTags.has('wrx90')) {
                    requiredCpuTags = ['amd'];
                }

                if (requiredCpuTags.length > 0) {
                    productsToShow = productsToShow.filter(cpu =>
                        cpu.tags.some(tag => requiredCpuTags.includes(tag.toLowerCase()))
                    );
                    compatibilityFilterApplied = true;
                }
            }
        }

        modalTitle.textContent = `Select a ${componentData.name}`;
        modalBody.innerHTML = '';

        const searchHtml = `<input type="text" id="modal-search-input" placeholder="Search products by name..." class="modal-search-input mb-4">`;
        modalBody.insertAdjacentHTML('beforeend', searchHtml);

        if (!compatibilityFilterApplied && componentConfig && componentConfig.filters && componentConfig.filters.length > 0) {
            let filterHtml = `<div class="modal-filter-container"><button class="modal-filter-btn active" data-filter="All">All</button>`;
            componentConfig.filters.forEach(filterName => {
                filterHtml += `<button class="modal-filter-btn" data-filter="${filterName}">${filterName}</button>`;
            });
            filterHtml += `</div>`;
            modalBody.insertAdjacentHTML('beforeend', filterHtml);
        }

        const productListContainer = document.createElement('div');
        productListContainer.id = 'modal-product-list';
        productListContainer.className = 'grid grid-cols-1 gap-4';
        modalBody.appendChild(productListContainer);

        if (productsToShow.length === 0) {
            productListContainer.innerHTML = `<p class="text-[color:var(--pcb-text-muted)] text-center p-8">No compatible products found.</p>`;
        } else {
            filterAndRenderProducts(handle, productsToShow);
        }

        window.currentProductsToShow = productsToShow;

        modal.classList.remove('hidden');
        setTimeout(() => modalContent.classList.remove('scale-95', 'opacity-0'), 10);

        const searchInput = document.getElementById('modal-search-input');
        searchInput.addEventListener('input', () => {
            filterAndRenderProducts(currentModalHandle, productsToShow);
        });
    }

    function closeModal() {
        modalContent.classList.add('scale-95', 'opacity-0');
        setTimeout(() => modal.classList.add('hidden'), 300);
    }

    function selectProduct(handle, product) {
        const componentConfig = window.pcBuilderConfig.components.find(c => c.requiredTag.replace(/[^a-z0-9]/gi, '').toLowerCase() === handle);

        const newSelection = { product: product, quantity: 1, id: Date.now() + Math.random() };

        if (!state.selectedComponents[handle]) {
            state.selectedComponents[handle] = [];
        }

        const selectionArray = state.selectedComponents[handle];

        if (componentConfig && componentConfig.allowMultiple) {
            const existingSelection = selectionArray.find(s => s.product.legacyVariantId === product.legacyVariantId);
            if (existingSelection) {
                existingSelection.quantity++;
            } else {
                selectionArray.push(newSelection);
            }
        } else {
            state.selectedComponents[handle] = [newSelection];
        }

        updateUI();
        closeModal();
    }

    function checkCompatibility(cpuSelection, motherboardSelection) {
        if (!cpuSelection || !motherboardSelection) return true;
        const cpuTags = cpuSelection.product.tags.map(t => t.toLowerCase());
        const moboTags = motherboardSelection.product.tags.map(t => t.toLowerCase());
        const isIntelCompatible = cpuTags.includes('intel') && moboTags.includes('intel');
        const isAmdCompatible = cpuTags.includes('amd') && moboTags.includes('amd');
        return isIntelCompatible || isAmdCompatible;
    }

    function changeQuantity(handle, itemId, change) {
        const selectionArray = state.selectedComponents[handle];
        if (!selectionArray) return;
        const selection = selectionArray.find(s => s.id === itemId);
        if (selection) {
            const newQuantity = selection.quantity + change;
            if (newQuantity >= 1) {
                selection.quantity = newQuantity;
                updateUI();
            }
        }
    }

    function removeComponent(handle, itemId) {
        const selectionArray = state.selectedComponents[handle];
        if (!selectionArray) return;
        state.selectedComponents[handle] = selectionArray.filter(s => s.id !== itemId);
        if (state.selectedComponents[handle].length === 0) {
            delete state.selectedComponents[handle];
        }
        updateUI();
    }

    const formatMoney = (cents, currencyCode = 'AUD') => {
        const amount = (cents / 100).toFixed(2);
        return currencyCode.length > 1 ? `${currencyCode} ${amount}` : `${currencyCode}${amount}`;
    };

    function updateUI() {
        let totalPrice = 0;
        summaryItemsEl.innerHTML = '';
        window.componentHandles.forEach(handle => {
            const selectionArray = state.selectedComponents[handle];
            const rowEl = document.getElementById(`row-${handle}`);
            const selectedEl = document.getElementById(`selected-${handle}`);

            if (selectionArray && selectionArray.length > 0 && rowEl) {
                selectedEl.innerHTML = selectionArray.map(selection => {
                    const component = selection.product;
                    const quantity = selection.quantity;
                    return `
                        <div class="flex items-center justify-between py-2 border-b last:border-b-0">
                            <div class="flex items-center gap-4">
                                <img src="${component.image}" alt="${component.title}" class="w-12 h-12 object-cover rounded-md flex-shrink-0">
                                <div>
                                    <p class="font-medium text-[color:var(--pcb-text-light)] text-sm">${component.title}</p>
                                    <p class="text-[color:var(--pcb-text-muted)] text-sm">${component.priceFormatted}</p>
                                </div>
                            </div>
                            <div class="quantity-selector">
                                <button class="quantity-btn" data-handle="${handle}" data-item-id="${selection.id}" data-change="-1">-</button>
                                <input type="number" value="${quantity}" min="1" class="quantity-input" readonly>
                                <button class="quantity-btn" data-handle="${handle}" data-item-id="${selection.id}" data-change="1">+</button>
                            </div>
                        </div>`;
                }).join('');

                rowEl.classList.remove('border-transparent');
                rowEl.classList.add('border-[color:var(--pcb-primary-color)]', 'shadow-md');

                selectionArray.forEach(selection => {
                    const component = selection.product;
                    const quantity = selection.quantity;
                    const subTotal = component.price * quantity;
                    const summaryItem = document.createElement('div');
                    summaryItem.className = 'flex justify-between items-start py-2 border-b last:border-b-0';
                    summaryItem.innerHTML = `
                        <div class="flex-grow pr-4 min-w-0">
                            <p class="font-semibold text-[color:var(--pcb-text-light)]">${window.pcBuilderData[handle].name}</p>
                            <p class="text-sm text-[color:var(--pcb-text-muted)] truncate" title="${component.title}">${component.title} (x${quantity})</p>
                        </div>
                        <div class="text-right flex-shrink-0">
                            <p class="font-mono font-semibold text-[color:var(--pcb-text-light)]">${formatMoney(subTotal, '$')}</p>
                            <button class="remove-item-btn text-xs text-red-500 hover:text-red-700 font-semibold" data-handle="${handle}" data-item-id="${selection.id}">Remove</button>
                        </div>`;
                    summaryItemsEl.appendChild(summaryItem);
                    totalPrice += subTotal;
                });

            } else if (rowEl) {
                selectedEl.innerHTML = `<p class="placeholder text-[color:var(--pcb-text-muted)] text-sm">Click 'Choose' to select an item</p>`;
                rowEl.classList.add('border-transparent');
                rowEl.classList.remove('border-[color:var(--pcb-primary-color)]', 'shadow-md');
            }
        });

        totalPriceEl.textContent = formatMoney(totalPrice, '$');
        addToCartBtn.disabled = Object.keys(state.selectedComponents).length === 0;
    }

    // SECTION 3: CART LOGIC
    async function addAllToCart() {
        let hasItems = false;

        const form = document.createElement('form');
        form.method = 'POST';
        form.action = '/cart/add';
        form.style.display = 'none';

        Object.values(state.selectedComponents).forEach(selectionArray => {
            selectionArray.forEach(selection => {
                const idInput = document.createElement('input');
                idInput.type = 'hidden';
                idInput.name = 'items[][id]';
                idInput.value = selection.product.legacyVariantId;
                form.appendChild(idInput);

                const quantityInput = document.createElement('input');
                quantityInput.type = 'hidden';
                quantityInput.name = 'items[][quantity]';
                quantityInput.value = selection.quantity;
                form.appendChild(quantityInput);

                hasItems = true;
            });
        });

        if (!hasItems) return;

        addToCartBtn.disabled = true;
        addToCartBtn.textContent = 'Adding...';

        const returnToInput = document.createElement('input');
        returnToInput.type = 'hidden';
        returnToInput.name = 'return_to';
        returnToInput.value = '/cart';
        form.appendChild(returnToInput);
        document.body.appendChild(form);
        form.submit();
    }

    // SECTION 4: EVENT LISTENERS & APP KICK OFF
    closeBtn.addEventListener('click', closeModal);
    modal.addEventListener('click', (e) => { if (e.target === modal) closeModal(); });
    addToCartBtn.addEventListener('click', addAllToCart);

    document.body.addEventListener('click', (e) => {
        if (e.target && e.target.classList.contains('select-btn')) {
            openModal(e.target.dataset.handle);
        }
        if (e.target && e.target.classList.contains('remove-item-btn')) {
            const handle = e.target.dataset.handle;
            const itemId = parseFloat(e.target.dataset.itemId);
            removeComponent(handle, itemId);
        }
        if (e.target && e.target.classList.contains('quantity-btn')) {
            const handle = e.target.dataset.handle;
            const itemId = parseFloat(e.target.dataset.itemId);
            const change = parseInt(e.target.dataset.change, 10);
            changeQuantity(handle, itemId, change);
        }
        if (e.target && e.target.classList.contains('modal-filter-btn')) {
            const filter = e.target.dataset.filter;
            document.querySelectorAll('.modal-filter-btn').forEach(btn => btn.classList.remove('active'));
            e.target.classList.add('active');
            filterAndRenderProducts(currentModalHandle, window.currentProductsToShow);
        }
    });

    initializeApp();
});