/**
 * Custom Add-to-Cart Handler for Slide Cart
 * This ensures products are added via AJAX and the slide cart opens instead of redirecting
 */
(function () {
    'use strict';

    // Wait for DOM to be ready for cart type override, but attach listeners immediately
    if (window.theme) {
        window.theme.cartType = 'drawer';
    } else {
        document.addEventListener('DOMContentLoaded', function () {
            if (window.theme) window.theme.cartType = 'drawer';
        });
    }

    // Check if a form is an add-to-cart form
    // Note: Forms with DPO (Dynamic Product Options) should redirect to /cart, not use AJAX
    function isAddToCartForm(form) {
        if (!form || !form.matches) return false;

        // Skip DPO forms - let them redirect to /cart naturally
        if (form.querySelector('.dpo-container')) {
            return false; // Don't intercept, allow default form submission to /cart
        }

        // Standard add-to-cart form without DPO - use AJAX and slide cart
        if (form.matches('form[action*="/cart/add"]')) {
            return true;
        }

        return false;
    }

    // Shared add-to-cart logic
    function handleAddToCart(form, submitBtn) {
        // Get form data
        var formData = new FormData(form);
        var data = {};
        formData.forEach(function (value, key) {
            // Handle array fields like properties
            if (key.endsWith('[]')) {
                var cleanKey = key.slice(0, -2);
                if (!data[cleanKey]) data[cleanKey] = [];
                data[cleanKey].push(value);
            } else {
                data[key] = value;
            }
        });        

        // Disable button
        if (submitBtn) {
            submitBtn.setAttribute('disabled', 'disabled');
            submitBtn.classList.add('is-loading');
        }

        // Show loading indicator
        document.dispatchEvent(new CustomEvent('theme:loading:start'));

        // Make AJAX request to add to cart
        fetch('/cart/add.js', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify(data),
            credentials: 'same-origin'
        })
            .then(function (response) {
                return response.json().then(function (responseData) {
                    return { ok: response.ok, data: responseData };
                });
            })
            .then(function (result) {
                document.dispatchEvent(new CustomEvent('theme:loading:end'));

                if (result.ok) {
                    // Re-enable button
                    if (submitBtn) {
                        submitBtn.removeAttribute('disabled');
                        submitBtn.classList.remove('is-loading');
                    }

                    // Get quantity that was added
                    var quantity = parseInt(data.quantity) || 1;

                    // Dispatch product:added event (theme listens for this)
                    document.documentElement.dispatchEvent(new CustomEvent('product:added', {
                        bubbles: true,
                        detail: {
                            variant: result.data,
                            button: submitBtn,
                            quantity: quantity
                        }
                    }));

                    // Also dispatch cart:refresh to update cart
                    document.documentElement.dispatchEvent(new CustomEvent('cart:refresh', {
                        bubbles: true,
                        detail: { scrollToTop: false }
                    }));

                    // Directly open the mini cart
                    openSlideCart();

                } else {
                    // Show error
                    if (submitBtn) {
                        submitBtn.removeAttribute('disabled');
                        submitBtn.classList.remove('is-loading');
                    }

                    var errorMessage = result.data.description || result.data.message || 'Could not add to cart';
                    alert(errorMessage);
                }
            })
            .catch(function (error) {
                console.error('Add to cart error:', error);
                document.dispatchEvent(new CustomEvent('theme:loading:end'));

                if (submitBtn) {
                    submitBtn.removeAttribute('disabled');
                    submitBtn.classList.remove('is-loading');
                }

                alert('An error occurred. Please try again.');
            });
    }

    // Intercept all add-to-cart form submissions
    document.addEventListener('submit', function (e) {
        var form = e.target;

        // Check if this is an add-to-cart form (including forms with DPO container)
        if (!isAddToCartForm(form)) {
            return;
        }

        // Prevent the default form submission
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();

        // Find the submit button
        var submitBtn = form.querySelector('[type="submit"], [data-action="add-to-cart"], [data-action="custom-add-to-cart"]');
        handleAddToCart(form, submitBtn);
    }, true); // Use capture phase


    // Function to open the slide cart
    function openSlideCart() {
        var miniCart = document.getElementById('mini-cart');
        var overlay = document.getElementById('slide-cart-overlay');

        if (miniCart) {
            // Set aria-hidden to false to trigger the slide animation
            miniCart.setAttribute('aria-hidden', 'false');

            // Update cart count in header
            updateCartCount();
        }

        if (overlay) {
            overlay.classList.add('is-visible');
        }

        // Update header icons (desktop and mobile)
        var toggles = document.querySelectorAll('[data-action="toggle-mini-cart"], .header__cart-toggle');
        toggles.forEach(function (toggle) {
            toggle.setAttribute('aria-expanded', 'true');
            var icon = toggle.querySelector('.header__cart-icon');
            if (icon) icon.setAttribute('aria-expanded', 'true');
        });

        document.body.style.overflow = 'hidden';
    }

    // Function to update cart count in header
    function updateCartCount() {
        fetch('/cart.js', {
            method: 'GET',
            headers: { 'Accept': 'application/json' }
        })
            .then(function (response) { return response.json(); })
            .then(function (cart) {
                // Update header cart count
                var cartCountElements = document.querySelectorAll('.header__cart-count');
                cartCountElements.forEach(function (el) {
                    el.textContent = cart.item_count;
                });

                // Update slide cart count badge
                var slideCartCount = document.querySelector('.slide-cart__count');
                if (slideCartCount) {
                    slideCartCount.textContent = cart.item_count;
                }
            })
            .catch(function (error) {
                console.error('Error fetching cart:', error);
            });
    }

    // Function to close the slide cart
    function closeSlideCart() {
        var miniCart = document.getElementById('mini-cart');
        var overlay = document.getElementById('slide-cart-overlay');

        if (miniCart) {
            miniCart.setAttribute('aria-hidden', 'true');

            // Remove focus trap that the theme's Accessibility class may have set
            // This is critical - without this, users can't interact with inputs outside the cart
            if (typeof Accessibility !== 'undefined' && Accessibility.removeTrapFocus) {
                Accessibility.removeTrapFocus(miniCart, 'mini-cart');
            }
            // Remove tabindex that trapFocus sets
            miniCart.removeAttribute('tabindex');
        }

        if (overlay) {
            overlay.classList.remove('is-visible');
        }

        // Update header icons (desktop and mobile)
        var toggles = document.querySelectorAll('[data-action="toggle-mini-cart"], .header__cart-toggle');
        toggles.forEach(function (toggle) {
            toggle.setAttribute('aria-expanded', 'false');
            var icon = toggle.querySelector('.header__cart-icon');
            if (icon) icon.setAttribute('aria-expanded', 'false');
        });

        document.body.style.overflow = '';
        document.body.classList.remove('no-mobile-scroll');
    }

    // Function to toggle the slide cart
    function toggleSlideCart() {
        var miniCart = document.getElementById('mini-cart');
        if (miniCart) {
            var isHidden = miniCart.getAttribute('aria-hidden') === 'true';
            if (isHidden) {
                openSlideCart();
            } else {
                closeSlideCart();
            }
        }
    }

    // Event delegation for clicks (works after cart re-renders)
    // Use capture phase to intercept before theme's handlers
    document.addEventListener('click', function (e) {
        // Close button click - check for close button or its children
        var closeBtn = e.target.closest('.slide-cart__close, [data-action="close-slide-cart"]');
        if (closeBtn) {
            e.preventDefault();
            e.stopPropagation();
            e.stopImmediatePropagation();
            closeSlideCart();
            return;
        }

        // Cart icon toggle - check for cart toggle link or its children
        var cartToggle = e.target.closest('[data-action="toggle-mini-cart"], .header__cart-toggle');
        if (cartToggle) {
            e.preventDefault();
            e.stopPropagation();
            e.stopImmediatePropagation();
            toggleSlideCart();
            return;
        }

        // Add-to-cart button click - intercept to prevent "double click" issues
        var addToCartBtn = e.target.closest('[data-action="add-to-cart"], [data-action="custom-add-to-cart"]');
        if (addToCartBtn && addToCartBtn.form) {
            if (isAddToCartForm(addToCartBtn.form)) {
                e.preventDefault();
                e.stopPropagation();
                e.stopImmediatePropagation();
                handleAddToCart(addToCartBtn.form, addToCartBtn);
                return;
            }
        }

        // Overlay click to close
        if (e.target.id === 'slide-cart-overlay') {
            closeSlideCart();
            return;
        }
    }, true); // Use capture phase to run before theme's handlers

    // Escape key to close
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            var miniCart = document.getElementById('mini-cart');
            if (miniCart && miniCart.getAttribute('aria-hidden') === 'false') {
                closeSlideCart();
            }
        }
    });

})();


/**
 * Lenis Smooth Scroll Initialization
 * High-performance smooth scrolling
 */
/*(function () {
    'use strict';

    if (window.hasLenisStarted) return;
    window.hasLenisStarted = true;

    // Wait for Lenis to be loaded
    function initLenis() {
        if (typeof Lenis === 'undefined') {
            // faster retry if not ready yet
            setTimeout(initLenis, 50);
            return;
        }

        const lenis = new Lenis({
            duration: 1.2,
            easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
            direction: 'vertical',
            gestureDirection: 'vertical',
            smooth: true,
            mouseMultiplier: 1,
            smoothTouch: false,
            touchMultiplier: 2,
        });

        function raf(time) {
            lenis.raf(time);
            requestAnimationFrame(raf);
        }

        requestAnimationFrame(raf);

        // Expose lenis instance globally if needed for other scripts
        window.lenis = lenis;

        console.log('Lenis Smooth Scroll Initialized');
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initLenis);
    } else {
        initLenis();
    }
})();*/
